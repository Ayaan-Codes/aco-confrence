export default (track: any) => track?.mediaStreamTrack;
